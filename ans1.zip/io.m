function a=io(n)
    temp = zeros(n,n);
    t = [1 5 6];
    for i=0:n-1
        if i == 0
           for l=0:1
               temp(i+1,l+i+1) = t(l+2);
           end
        elseif i ==n-1
            for l=0:1
                temp(i+1,l+i) = t(l+1);
            end
        else

            for l =0:2
                temp(i+1,i+l) = t(l+1);
            end
        end
    end
    a = temp;
end